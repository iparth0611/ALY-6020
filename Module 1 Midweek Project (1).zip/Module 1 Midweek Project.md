```python
import pandas as pd
import numpy as np
import matplotlib as plt
import seaborn as sns

from sklearn.datasets import load_iris
from sklearn.model_selection import train_test_split
from sklearn.neighbors import KNeighborsClassifier
from sklearn.datasets import make_classification
from sklearn.preprocessing import MinMaxScaler
from sklearn.metrics import accuracy_score
import matplotlib.pyplot as plt
from sklearn.metrics import confusion_matrix 

import warnings
warnings.filterwarnings("ignore")
```


```python
# Load the Iris dataset
iris = load_iris()
X = iris.data
y = iris.target
```


```python
# Split the data into training and test sets
X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.3, random_state=0)
```


```python
scaler = MinMaxScaler()
X_train = scaler.fit_transform(X_train)
X_test = scaler.transform(X_test)
```


```python
accuracy_rate = []

for k in range(1, 30):
    knn = KNeighborsClassifier(n_neighbors=k)
    knn.fit(X_train, y_train)
    predictions = knn.predict(X_test)
    accuracy_rate.append(knn.score(X_test, y_test))
```


```python
plt.figure(figsize=(10, 6))
plt.plot(range(1, 30), accuracy_rate, color='blue', linestyle='dashed', marker='o', markerfacecolor='red', markersize=10)
plt.title('Accuracy Rate vs. K Value')
plt.xlabel('K')
plt.ylabel('Accuracy Rate')
plt.show()
```


    
![png](output_5_0.png)
    



```python
# Create a KNN classifier with 10 neighbors
knn = KNeighborsClassifier(n_neighbors=10)
```


```python
knn.fit(X_train, y_train)
y_pred = knn.predict(X_test)

# Print the accuracy of the KNN model
print("Accuracy: {:.2f}%".format(knn.score(X_test, y_test) * 100))
```

    Accuracy: 97.78%
    


```python
#Confusion Matrix 
conf_matrix = confusion_matrix(y_test, y_pred) 
sns.heatmap(conf_matrix, annot=True, fmt='d', xticklabels=['setosa', 'versicolor', 'virginica'], yticklabels=['setosa', 'versicolor', 'virginica']) 
plt.ylabel('Actual') 
plt.xlabel('Predicted') 
plt.show()
```


    
![png](output_8_0.png)
    

